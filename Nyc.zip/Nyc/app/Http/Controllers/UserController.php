<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PrivacyPolicy;

class UserController extends Controller
{
    public function dashboard()
    {
    	return view('user.dashboard');
    }

    public function profile()
    {
    	return view('user.profile.profile');
    }

    public function privacy_policy()
    {
    	$privacy = PrivacyPolicy::first();

    	return view('user.privacy-policy.list',compact('privacy'));
    }
}
