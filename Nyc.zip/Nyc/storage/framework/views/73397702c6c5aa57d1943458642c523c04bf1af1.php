

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<section class="content">
    <div class="body_scroll">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <h2>Ticket list</h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index-2.html"><i class="zmdi zmdi-home"></i> Aero</a></li>
                        <li class="breadcrumb-item">Project</li>
                        <li class="breadcrumb-item active">Ticket list</li>
                    </ul>
                    <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                </div>
                <div class="col-lg-5 col-md-6 col-sm-12">                
                    <button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i class="zmdi zmdi-arrow-right"></i></button>
                    <button class="btn btn-success btn-icon float-right" type="button"><i class="zmdi zmdi-plus"></i></button>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row clearfix">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="card project_list">
                        <div class="table-responsive">
                            <table class="table table-hover c_table">
                                <thead>
                                    <tr>
                                        <th>Place Type</th>
                                        <th>Title</th>
                                        <th>Description</th>
                                        <th>Listing Type</th>
                                        <th>Bedrooms</th>
                                        <th>Guests</th>
                                        <th>Beds</th>
                                        <th>Bathrooms</th>
                                        <th>Rooms</th>
                                        <th>Size</th>
                                        <th>Measure Unit</th>
                                        <th>Affiliate Booking Link</th>
                                        <th>Amenities</th>
                                        <th>Contact</th>
                                        <th>Special Price From</th>
                                        <th>Special Price To</th>
                                        <th>Special Price</th>
                                        <th>Minimum Stay (Special)</th>
                                        <th>Nightly</th>
                                        <th>After Price Label</th>
                                        <th>Weekends</th>
                                        <th>Weekend Days</th>
                                        <th>Weekly Nights</th>
                                        <th>Monthly Nights</th>
                                        <th>Service Name</th>
                                        <th>Service Price</th>
                                        <th>Type</th>
                                        <th>Additional Guests</th>
                                        <th>Guests Allowed</th>
                                        <th>Guest Price</th>
                                        <th>Cleaning Fee</th>
                                        <th>Cleaning Fee Type</th>
                                        <th>City Fee</th>
                                        <th>City Fee Type</th>
                                        <th>Security Deposit</th>
                                        <th>Smoking Allowed</th>
                                        <th>Pets Allowed</th>
                                        <th>Party Allowed</th>
                                        <th>Children Allowed</th>
                                        <th>Fees</th>
                                        <th>Tax</th>
                                        <th>Youtube URL</th>
                                        <th>Cancellation Policy</th>
                                        <th>Daily Price</th>
                                        <th>Minimum Stay</th>
                                        <th>Location</th>
                                        <th>Latitude</th>
                                        <th>Longitude</th>
                                        <th>Property Images</th>
                                    </tr>
                                </thead>
                                <tbody>
                                	<?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                                    <tr>
	                                        <td><?php echo e(ucwords(str_replace('_',' ',$property->place_type)) ?? ''); ?></td>
                                            <td><?php echo e($property->title ?? ''); ?></td>
                                            <td class="description_data"><?php echo e(Str::limit($property->description,80)); ?> <?php if(strlen($property->description) > 80): ?> <span class="view_more text-blue" style="cursor:pointer">view more</span> <?php endif; ?></td>
                                            <td class="view_more_data" style="display:none"><?php echo e($property->description); ?></td>
                                            <td><?php echo e(ucwords($property->listing_type) ?? ''); ?></td>
                                            <td><?php echo e($property->bedrooms ?? ''); ?></td>
                                            <td><?php echo e($property->guests ?? ''); ?></td>
                                            <td><?php echo e($property->beds ?? ''); ?></td>
                                            <td><?php echo e($property->bathrooms ?? ''); ?></td>
                                            <td><?php echo e($property->rooms ?? ''); ?></td>
                                            <td><?php echo e($property->size ?? ''); ?></td>
                                            <td><?php echo e($property->measure_unit ?? ''); ?></td>
                                            <td><?php echo e($property->affiliate_booking_link ?? ''); ?></td>
                                            <td>
                                                <?php if($property->amenities != null): ?>
                                                    <?php $__currentLoopData = $property->amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php echo e($amenities.','); ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($property->phone ?? ''); ?></td>
                                            <td>
                                                <?php if($property->price_from): ?>
                                                <?php $__currentLoopData = $property->price_from; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price_from): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($price_from.','); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($property->price_from): ?>
                                                <?php $__currentLoopData = $property->price_to; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price_to): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($price_to.','); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </td>

                                            <td>
                                                <?php if($property->price_from): ?>
                                                <?php $__currentLoopData = $property->from_to_price; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $from_to_price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($from_to_price.','); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($property->min_stay ?? ''); ?></td>
                                            <td><?php echo e($property->one_night_price ?? ''); ?></td>
                                            <td><?php echo e($property->after_price_label ?? ''); ?></td>
                                            <td><?php echo e($property->weekend_price_per_day ?? ''); ?></td>
                                            <td><?php echo e($property->weekend_days ?? ''); ?></td>
                                            <td><?php echo e($property->weekly_price_per_day ?? ''); ?></td>
                                            <td><?php echo e($property->montly_price_per_day ?? ''); ?></td>
                                            <td><?php echo e($property->service_name ?? ''); ?></td>
                                            <td><?php echo e($property->service_price ?? ''); ?></td>
                                            <td><?php echo e($property->service_fee_type ?? ''); ?></td>
                                            <td><?php echo e($property->additional_guests ?? ''); ?></td>
                                            <td><?php echo e($property->price_per_guest ?? ''); ?></td>
                                            <td><?php echo e($property->number_of_guests ?? ''); ?></td>
                                            <td><?php echo e($property->cleaning_fee ?? ''); ?></td>
                                            <td><?php echo e($property->cleaning_fee_type ?? ''); ?></td>
                                            <td><?php echo e($property->city_fee ?? ''); ?></td>
                                            <td><?php echo e($property->city_fee_type ?? ''); ?></td>
                                            <td><?php echo e($property->security_deposit ?? ''); ?></td>
                                            <td><?php echo e($property->smoking_allowed ?? ''); ?></td>
                                            <td><?php echo e($property->pets_allowed ?? ''); ?></td>
                                            <td><?php echo e($property->party_allowed ?? ''); ?></td>
                                            <td><?php echo e($property->children_allowed ?? ''); ?></td>
                                            <td><?php echo e($property->fees ?? ''); ?></td>
                                            <td><?php echo e($property->tax ?? ''); ?></td>
                                            <td><?php echo e($property->youtube_url ?? ''); ?></td>
                                            <td><?php echo e($property->cancellation_policy ?? ''); ?></td>
                                            <td><?php echo e($property->default_price ?? ''); ?></td>
                                            <td><?php echo e($property->default_min_stay ?? ''); ?></td>
                                            <td><?php echo e($property->location ?? ''); ?></td>
                                            <td><?php echo e($property->latitude ?? ''); ?></td>
                                            <td><?php echo e($property->longitude ?? ''); ?></td>
                                            <td>
                                                <?php $__currentLoopData = $property->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <img src="<?php echo e(asset('storage/'.$image)); ?>" height="80" width="80">
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
	                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('host.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\Nyc\resources\views/host/property/list.blade.php ENDPATH**/ ?>