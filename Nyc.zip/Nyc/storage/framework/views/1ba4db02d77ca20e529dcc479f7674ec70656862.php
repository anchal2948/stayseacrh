

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<section class="content">
    <div class="body_scroll">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <h2>Booking list</h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index-2.html"><i class="zmdi zmdi-home"></i> Aero</a></li>
                        <li class="breadcrumb-item">Bookings</li>
                        <!-- <li class="breadcrumb-item active">Blog list</li> -->
                    </ul>
                    <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row clearfix">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="card project_list">
                        <div class="table-responsive">
                            <table class="table table-hover c_table">
                                <thead>
                                    <tr>
                                        <th>S no.</th>
                                        <th>User</th>
                                        <th>User's Phone</th>
                                        <th>User' Email</th>
                                        <th>Property</th>
                                        <th>CheckIn Date</th>
                                        <th>Checkout Date</th>
                                        <th>Price (Per day)</th>
                                        <th>Price (Total)</th>
                                        <th>Message</th>
                                    </tr>
                                </thead>
                                <tbody>
                                	<?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                                    <tr>
	                                        <td><?php echo e($bookings->firstItem() + $key); ?></td>
	                                        <td><?php echo e($booking->user->name); ?></td>
                                            <td><?php echo e($booking->user->phone); ?></td>
                                            <td><?php echo e($booking->user->email); ?></td>
                                            <td><?php echo e($booking->property->title); ?></td>
                                            <td><?php echo e($booking->checkin_date); ?></td>
                                            <td><?php echo e($booking->checkout_date); ?></td>
                                            <td><?php echo e($booking->price_per_day); ?></td>
                                            <td><?php echo e($booking->total_price); ?></td>
                                            <td><?php echo e($booking->message); ?></td>
	                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <?php echo e($bookings->links('vendor.pagination.bootstrap-5')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('host.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\Nyc\resources\views/host/bookings/list.blade.php ENDPATH**/ ?>