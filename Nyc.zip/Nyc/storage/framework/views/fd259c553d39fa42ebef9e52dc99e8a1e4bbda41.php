<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Room Booking</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.2.0/fullcalendar.min.css" rel="stylesheet">
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f7fc;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            padding: 20px;
        }

        .booking-container {
            background: #ffffff;
            width: 100%;
            max-width: 1200px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            padding: 40px;
            text-align: center;
            overflow: hidden;
        }

        .header {
            font-size: 32px;
            color: #2c3e50;
            margin-bottom: 40px;
            font-weight: bold;
        }

        .calendars-wrapper {
            display: flex;
            gap: 30px;
            justify-content: space-between;
            margin-bottom: 40px;
            flex-wrap: wrap;
        }

        .calendar-container {
            width: 48%;
            background-color: #fff;
            border-radius: 15px;
            padding: 15px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
            position: relative;
        }

        /* FullCalendar Styling */
        .fc {
            border-radius: 15px;
            overflow: hidden;
        }

        .fc-toolbar {
            background-color: #3498db;
            color: white;
            padding: 12px;
            border-radius: 15px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .fc-toolbar h2 {
            font-size: 22px;
            margin: 0;
            text-align: center;
        }

        .fc-day-number {
            font-weight: bold;
            color: #333;
            font-size: 16px;
        }

        .fc-day-today {
            background-color: #ff5722 !important;
            color: white !important;
        }

        .fc-day-selected {
            background-color: #3498db !important;
            color: white !important;
        }

        .fc-event {
            background-color: #f39c12 !important; /* Yellow for events */
            color: #fff !important;
            border-radius: 5px;
            padding: 5px;
            font-size: 14px;
        }

        .fc-event:hover {
            background-color: #e67e22 !important;
        }

        /* Price Summary Styling */
        .price-summary {
            background-color: #ecf0f1;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
            margin-top: 40px;
        }

        .price-summary h3 {
            font-size: 26px;
            color: #2c3e50;
            margin-bottom: 15px;
            font-weight: 600;
        }

        .price-summary p {
            font-size: 20px;
            color: #34495e;
        }

        .price-summary .price {
            font-size: 32px;
            font-weight: bold;
            color: #3498db;
            margin-bottom: 15px;
        }

        .btn-booking {
            margin-top: 20px;
            padding: 14px 25px;
            font-size: 20px;
            font-weight: bold;
            color: #fff;
            background-color: #3498db;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .btn-booking:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .calendars-wrapper {
                flex-direction: column;
                align-items: center;
            }

            .calendar-container {
                width: 100%;
                margin-bottom: 20px;
            }

            .btn-booking {
                width: 100%;
                padding: 18px;
            }
        }

    </style>
</head>
<body>
    <div class="booking-container">
        <div class="header">Room Booking</div>

        <div class="calendars-wrapper">
            <!-- From Date Calendar -->
            <div class="calendar-container" id="from-calendar"></div>
            
            <!-- To Date Calendar -->
            <div class="calendar-container" id="to-calendar"></div>
        </div>

        <!-- Price Summary -->
        <div class="price-summary">
            <h3>Booking Summary</h3>
            <p class="avg-price">Average Price per Day: <span id="avg-price">$0.00</span></p>
            <p class="total-price">Total Price: <span id="total-price">$0.00</span></p>
        </div>

        <button class="btn-booking" id="book-room">Confirm Booking</button>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.2.0/fullcalendar.min.js"></script>
    <script>
        $(document).ready(function() {
            let selectedStartDate = null;
            let selectedEndDate = null;
            let events = <?php echo json_encode($events, 15, 512) ?>; // Pass events from the controller (with prices in the backend)

            // Initialize From Date Calendar
            $('#from-calendar').fullCalendar({
                events: events,
                selectable: true,
                select: function(start, end) {
                    selectedStartDate = start;
                    $('#to-calendar').fullCalendar('gotoDate', start);
                    if (selectedEndDate) {
                        calculatePrice();
                    }
                    $(this).fullCalendar('unselect');
                },
                header: {
                    left: 'prev,next',  // Just previous and next buttons
                    center: 'title',    // Center the title (month/year)
                    right: ''           // Remove the view options (month, week, day)
                },
                themeSystem: 'bootstrap4', // Optional for bootstrap theme
                eventRender: function(event, element) {
                    element.find('.fc-title').text(event.title);  // Just show title
                    element.find('.fc-price').remove();  // Ensure no price is displayed
                    element.find('.fc-event').removeClass('fc-event').addClass('fc-no-price'); // Optional: Add class to remove any price-related styling
                }
            });

            // Initialize To Date Calendar
            $('#to-calendar').fullCalendar({
                events: events,
                selectable: true,
                select: function(start, end) {
                    selectedEndDate = start;
                    calculatePrice();
                    $(this).fullCalendar('unselect');
                },
                header: {
                    left: 'prev,next',  // Just previous and next buttons
                    center: 'title',    // Center the title (month/year)
                    right: ''           // Remove the view options (month, week, day)
                },
                themeSystem: 'bootstrap4', // Optional for bootstrap theme
                eventRender: function(event, element) {
                    element.find('.fc-title').text(event.title);  // Just show title
                    element.find('.fc-price').remove();  // Ensure no price is displayed
                    element.find('.fc-event').removeClass('fc-event').addClass('fc-no-price'); // Optional: Add class to remove any price-related styling
                }
            });

            // Function to calculate total and average price based on selected dates
            function calculatePrice() {
                if (selectedStartDate && selectedEndDate) {
                    let totalPrice = 0;
                    let totalDays = 0;

                    let selectedStart = moment(selectedStartDate);
                    let selectedEnd = moment(selectedEndDate).add(1, 'days'); // Add 1 day to include the end date

                    let selectedDates = [];
                    let currentDay = selectedStart.clone();

                    while (currentDay.isBefore(selectedEnd)) {
                        selectedDates.push(currentDay.format('YYYY-MM-DD'));
                        currentDay.add(1, 'days');
                    }

                    selectedDates.forEach((date) => {
                        let dailyPrice = 0;
                        events.forEach(event => {
                            let eventStart = moment(event.start);
                            let eventEnd = moment(event.end);
                            if (moment(date).isBetween(eventStart, eventEnd, 'day', '[]')) {
                                dailyPrice = parseFloat(event.price);
                            }
                        });
                        totalPrice += dailyPrice;
                        totalDays++;
                    });

                    let avgPrice = (totalDays > 0) ? totalPrice / totalDays : 0;

                    $('#avg-price').text('$' + avgPrice.toFixed(2));
                    $('#total-price').text('$' + totalPrice.toFixed(2));
                }
            }
        });
    </script>
</body>
</html>
<?php /**PATH C:\Users\admin\Desktop\Nyc\resources\views/user/properties/dummy.blade.php ENDPATH**/ ?>