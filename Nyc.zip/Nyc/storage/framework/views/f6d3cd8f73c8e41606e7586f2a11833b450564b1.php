

<?php $__env->startSection('css'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main>
    <section class="blog_banner listin_banner">
        <h1>
            Dream Rooms
        </h1>
    </section>
    <section class="listing_card py-5">
        <div class="container-fluid px-4">
            <div class="row">
            	<div class="col-3">
		            <select class="form-control" id="location_filter">
		            	<option class="text-dark">Select Location</option>
		            	<?php $__currentLoopData = $filter_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		            		<option class="text-dark" value="<?php echo e($location->location); ?>"><?php echo e($location->location); ?></option>
		            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		            </select>
            	</div>
            </div>
            <br>
            <div class="row g-4">
                <div class="col-lg-7">
                    <div class="row g-4">
                    	<?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                        <div class="col-lg-6">
	                        	<a href="<?php echo e(route('property-detail',['id' => $property->id])); ?>">
	                            <div class="card">
	                                <div id="carouselExample1" class="carousel slide" data-bs-ride="carousel">
	                                    <div class="carousel-inner">
	                                    	<?php $__currentLoopData = $property->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                                        <div class="carousel-item <?php if($key == 0): ?> active <?php endif; ?>">
		                                            <img src="<?php echo e(asset('storage/'.$image)); ?>" class="d-block listing_imgs" alt="First slide" />
		                                        </div>
	                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                                       <!--  <div class="carousel-item">
	                                            <img src="assest/images/luxury_img2.webp" class="d-block listing_imgs" alt="Second slide" />
	                                        </div>
	                                        <div class="carousel-item">
	                                            <img src="assest/images/luxury_img1.webp" class="d-block listing_imgs" alt="Third slide" />
	                                        </div> -->
	                                    </div>
	                                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample1" data-bs-slide="prev">
	                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
	                                        <span class="visually-hidden">Previous</span>
	                                    </button>
	                                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample1" data-bs-slide="next">
	                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
	                                        <span class="visually-hidden">Next</span>
	                                    </button>
	                                </div>
	                                <div class="card-body">
	                                    <h5 class="card-title"><?php echo e($property->title); ?></h5>
	                                    <p class="card-text card_room_text">Pompano beach Florida.</p>
	                                    <div class="d-flex justify-content-between">
	                                        <div class="d-flex">
	                                            <div class="pe-3">
	                                                <div class="styles_roomsAndPrice">Bedrooms</div>
	                                                <div class="property_cardvalue"><?php echo e($property->bedrooms); ?></div>
	                                            </div>
	                                            <div class="ps-3 border-start">
	                                                <div class="styles_roomsAndPrice">Bathrooms</div>
	                                                <div class="property_cardvalue"><?php echo e($property->bathrooms); ?></div>
	                                            </div>
	                                        </div>
	                                        <div style="text-align: right;">
	                                            <div class="styles_roomsAndPrice">Avg. price per 7+ nights (per day)</div>
	                                            <div class="property_cardvalue">$<?php echo e($property->weekend_price_per_day); ?></div>
	                                        </div>
	                                    </div>
	                                    <div class="amenities">
	                                        <div class="hoverable">
	                                            <svg width="1.2em" height="1.2em" viewBox="0 0 22 16" fill="none" xmlns="http://www.w3.org/2000/svg">
	                                                <path
	                                                    d="M10.984.801C7.026.837 3.602 2.204.744 4.958c-.112.107-.222.207-.387.19-.154-.016-.277-.096-.329-.24-.06-.167-.026-.319.11-.453A14.622 14.622 0 0 1 2.103 2.8C4.94.828 8.084-.117 11.533.01c3.996.15 7.426 1.65 10.297 4.433.206.2.225.436.057.609-.168.172-.41.159-.617-.048a14.275 14.275 0 0 0-3.183-2.392 14.5 14.5 0 0 0-6.29-1.81c-.27-.015-.54-.002-.813-.002Z"
	                                                    fill="#000"
	                                                ></path>
	                                                <path
	                                                    d="M11.02 3.13c3.326.043 6.207 1.187 8.606 3.51.16.154.222.325.11.524-.101.183-.27.224-.466.172-.078-.02-.13-.073-.183-.126-1.748-1.705-3.822-2.793-6.231-3.157-3.733-.562-7.004.454-9.791 3.013-.055.05-.109.104-.165.155-.195.178-.421.183-.58.015-.16-.168-.149-.393.037-.58.338-.342.698-.66 1.08-.952C5.6 4.046 8.043 3.188 10.77 3.13c.085-.002.167 0 .25 0Z"
	                                                    fill="#000"
	                                                ></path>
	                                                <path
	                                                    d="M10.999 6.242c2.412.043 4.516.86 6.288 2.516a.918.918 0 0 1 .234.301c.079.179.09.333-.082.46a.402.402 0 0 1-.535-.031c-.588-.605-1.27-1.08-2.01-1.477-3.16-1.698-7.164-1.13-9.727 1.38-.225.22-.455.244-.632.066s-.15-.417.091-.644C6.41 7.119 8.537 6.278 11 6.243Z"
	                                                    fill="#000"
	                                                ></path>
	                                                <path
	                                                    d="M10.983 9.37c1.601.027 2.995.57 4.168 1.67.156.145.25.305.172.518-.105.29-.443.323-.701.072-.621-.601-1.344-1.041-2.18-1.262-1.922-.508-3.628-.09-5.096 1.26-.163.15-.332.208-.529.096-.175-.098-.211-.262-.169-.449.022-.092.086-.157.15-.22 1.175-1.11 2.575-1.658 4.185-1.686ZM11.016 15.663a1.58 1.58 0 0 1-1.6-1.6 1.6 1.6 0 1 1 1.6 1.6Z"
	                                                    fill="#000"
	                                                ></path>
	                                            </svg>
	                                        </div>
	                                        <div class="">
	                                            <svg width="1.2em" height="1.2em" viewBox="0 0 15 20" fill="none" xmlns="http://www.w3.org/2000/svg">
	                                                <path
	                                                    d="M14.444 7.778A2.779 2.779 0 0 0 11.667 5h-.556v-.556c0-.91-.755-1.666-1.667-1.666H8.89V1.11h.978a4.98 4.98 0 0 1 2.11.489.506.506 0 0 0 .245.067c.2 0 .4-.111.49-.311.132-.267.021-.6-.245-.756-.8-.378-1.69-.6-2.6-.6H4.444a.55.55 0 0 0-.555.556.55.55 0 0 0 .555.555h1.112v1.667H5c-.911 0-1.667.755-1.667 1.666V5h-.555A2.779 2.779 0 0 0 0 7.778v9.444A2.779 2.779 0 0 0 2.778 20h8.889a2.779 2.779 0 0 0 2.777-2.778V7.778ZM6.667 1.11h1.11v1.667h-1.11V1.11ZM4.444 4.444A.55.55 0 0 1 5 3.89h4.444a.55.55 0 0 1 .556.555V5H4.444v-.556Zm8.89 12.778c0 .911-.756 1.667-1.667 1.667h-8.89a1.679 1.679 0 0 1-1.666-1.667V7.778c0-.911.756-1.667 1.667-1.667h8.889c.91 0 1.666.756 1.666 1.667v9.444Z"
	                                                    fill="#000"
	                                                ></path>
	                                            </svg>
	                                        </div>
	                                        <div class="">
	                                            <svg width="1.2em" height="1.2em" viewBox="0 0 20 20" fill="none">
	                                                <path
	                                                    d="M19.583 20H.417A.417.417 0 0 1 0 19.583V16.25c0-.23.187-.417.417-.417h9.674l2.292-9.166H.417A.417.417 0 0 1 0 6.25V.417C0 .187.187 0 .417 0h19.167c.229 0 .416.187.416.417v19.166c0 .23-.187.417-.416.417Zm-18.75-.833h18.334V.834H.832v5h12.084a.414.414 0 0 1 .404.518l-2.5 10a.416.416 0 0 1-.404.315H.834v2.5Z"
	                                                    fill="#000"
	                                                ></path>
	                                                <path
	                                                    d="M5 6.667h.834v1.667H5V6.667ZM5.903 16.667H4.93a3.267 3.267 0 0 1-3.263-3.264v-2.986c0-.23.186-.417.416-.417H8.75c.23 0 .417.187.417.417v2.986c0 1.8-1.464 3.264-3.263 3.264ZM2.5 10.833v2.57c0 1.34 1.09 2.43 2.43 2.43h.973c1.34 0 2.43-1.09 2.43-2.43v-2.57H2.5Z"
	                                                    fill="#000"
	                                                ></path>
	                                                <path
	                                                    d="M2.5 14.167H1.233c-.68 0-1.233-.553-1.233-1.233v-.867c0-.68.554-1.233 1.233-1.233h.434v.834h-.434a.4.4 0 0 0-.4.399v.867c0 .22.18.4.4.4H2.5v.833ZM17.917 18.333h-3.333a.417.417 0 0 1-.417-.417V16.25c0-.23.188-.417.417-.417h3.333c.23 0 .417.187.417.417v1.666c0 .23-.188.417-.417.417ZM15 17.5h2.5v-.833H15v.833Z"
	                                                    fill="#000"
	                                                ></path>
	                                            </svg>
	                                        </div>
	                                        <div class="">
	                                            <svg width="1.2em" height="1.2em" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
	                                                <path
	                                                    d="M18.666 0H8.66a1.335 1.335 0 0 0-1.334 1.334V8.37a1.96 1.96 0 0 0-1 .484 2.004 2.004 0 0 0-3.113.583 1.672 1.672 0 0 0-2.221 1.617 1.333 1.333 0 0 0 .37 2.622l.52 4.168a1.339 1.339 0 0 0 1.325 1.168c.12.008 6.975-.013 6.787 0h7.338a1.335 1.335 0 0 0 1.334-1.334v-.333A1.335 1.335 0 0 0 20 16.009V1.334A1.335 1.335 0 0 0 18.666 0ZM8.66.667h10.006a.668.668 0 0 1 .667.667V4.67h-2.001v-.334a1.003 1.003 0 0 0-1-1h-5.337a1.002 1.002 0 0 0-1.001 1v.334H7.993V1.334A.668.668 0 0 1 8.66.667Zm8.005 4.003H10.66v-.334c0-.184.15-.333.334-.333h5.336c.184 0 .334.149.334.333v.334ZM2.656 10.006c.196 0 .387.059.55.167a.333.333 0 0 0 .505-.187 1.339 1.339 0 0 1 1.28-.98c.422-.001.818.2 1.066.541a.345.345 0 0 0 .536 0 1.333 1.333 0 0 1 2.346.439.335.335 0 0 0 .506.188.988.988 0 0 1 1.256.126c.188.187.293.441.294.707H6.992a.334.334 0 0 0-.333.333v.334a.338.338 0 0 1-.334.333 1.002 1.002 0 0 0-1 1v1.168a.5.5 0 1 1-1.001 0v-1.167a1.002 1.002 0 0 0-1-1H2.99a.334.334 0 0 1-.334-.334v-.334a.334.334 0 0 0-.333-.333h-.667a1.002 1.002 0 0 1 1-1Zm4.372 2.377a.981.981 0 0 0 .298-.71h4.002a.667.667 0 0 1 0 1.335H5.992c0-.184.149-.333.333-.334a.975.975 0 0 0 .703-.29Zm4.63-1.33a1.65 1.65 0 0 0-.674-1.38c1.43-2.81 5.65-1.825 5.68 1.334a3.015 3.015 0 0 1-4.68 2.489 1.331 1.331 0 0 0-.325-2.443Zm-.383 2.735c2.329 2.044 6.08.32 6.056-2.781-.052-3.88-5.202-5.064-6.958-1.62a1.542 1.542 0 0 0-.728-.006c1.85-4.364 8.275-3.136 8.354 1.626.045 3.452-4.026 5.576-6.82 3.547l.096-.766ZM.655 12.341a.672.672 0 0 1 .667-.667h.667a1.002 1.002 0 0 0 1 1h.334c.184 0 .333.15.334.334H1.322a.668.668 0 0 1-.667-.667Zm1.888 5.418-.51-4.084h1.624v.5a1.168 1.168 0 0 0 2.334 0v-.5h4.626l-.51 4.084a.67.67 0 0 1-.664.585H3.206a.67.67 0 0 1-.663-.585ZM18 17.677a.668.668 0 0 1-.668.667h-6.736c.146-.314.227-.654.236-1h7.168v.333Zm.667-1h-7.752l.173-1.386c3.247 2.026 7.63-.454 7.579-4.285-.081-5.395-7.302-6.908-9.566-2.043a1.998 1.998 0 0 0-1.107-.593V5.337h11.34V16.01a.668.668 0 0 1-.667.667Z"
	                                                    fill="#000"
	                                                ></path>
	                                                <path
	                                                    d="M15.664 3.002a1 1 0 0 0 0-2.001 1 1 0 0 0 0 2.001Zm0-1.334a.334.334 0 0 1 0 .667.334.334 0 0 1 0-.667ZM17.999 3.002a1 1 0 0 0 0-2.001 1 1 0 0 0 0 2.001Zm0-1.334a.334.334 0 0 1 0 .667.334.334 0 0 1 0-.667ZM4.991 15.676a1.001 1.001 0 0 0 0 2.001 1 1 0 0 0 0-2Zm0 1.335a.334.334 0 0 1 0-.668.334.334 0 0 1 0 .668Z"
	                                                    fill="#000"
	                                                ></path>
	                                            </svg>
	                                        </div>
	                                        <div class="">
	                                            <svg width="1.2em" height="1.2em" viewBox="0 0 20 12" fill="none">
	                                                <path
	                                                    d="M1.504 8.662h.201v2.168c0 .139.112.251.25.251h2.012a.25.25 0 00.25-.25V8.661h1.936v1.236c0 .138.112.25.25.25h9.38v.682c0 .139.112.251.25.251h2.011a.25.25 0 00.25-.25V8.661h.202c.83 0 1.504-.675 1.504-1.504 0-.83-.675-1.504-1.504-1.504h-.912v-.157c0-.588-.479-1.067-1.067-1.067H7.22c-.589 0-1.067.479-1.067 1.067v.157h-.927V2.83a.937.937 0 00-.936-.936H3.008v-.39C3.008.674 2.333 0 1.504 0 .674 0 0 .675 0 1.504v5.654c0 .83.675 1.504 1.504 1.504zm16.08-2.507h.912a1.004 1.004 0 010 2.006h-.912V6.155zm-.251 3.993a.25.25 0 00.25-.25V8.662h.21v1.918h-1.51v-.432h1.05zM6.654 5.497c0-.312.254-.566.565-.566h9.298c.312 0 .565.254.565.566v4.15H6.654v-4.15zM3.716 10.58h-1.51V8.662h1.51v1.918zm-.708-8.184H4.29c.24 0 .435.195.435.434v2.824H3.008V2.396zM.5 1.504a1.004 1.004 0 012.006 0v4.4c0 .14.112.251.25.251h3.396v2.006H1.504C.951 8.16.502 7.71.502 7.158V1.504z"
	                                                    fill="#000"
	                                                ></path>
	                                            </svg>
	                                        </div>
	                                        <div class="">
	                                            <svg width="1.2em" height="1.2em" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
	                                                <path
	                                                    d="M18.937 8.189h-4.213v-.906a.276.276 0 0 0-.275-.275h-1.772a.276.276 0 0 0-.275.275v.906h-1.22V6.457h2.48a1.063 1.063 0 0 0 1.063-1.063V1.063A1.063 1.063 0 0 0 13.662 0H6.338a1.063 1.063 0 0 0-1.063 1.063v4.33a1.063 1.063 0 0 0 1.063 1.064h2.48v1.732h-.866v-.906a.275.275 0 0 0-.276-.275H1.378a.276.276 0 0 0-.276.275v.906h-.039a1.063 1.063 0 1 0 0 2.126h.433v9.41c0 .152.124.275.276.275H3.11a.276.276 0 0 0 .276-.276V18.19h7.874v1.535c0 .153.123.276.275.276h1.339a.276.276 0 0 0 .276-.276V18.19h3.464v1.535c0 .153.124.276.276.276h1.338a.276.276 0 0 0 .276-.276v-9.41h.433a1.063 1.063 0 0 0 0-2.125Zm-5.984-.63h1.22v.63h-1.22v-.63ZM5.827 5.394V1.063c0-.283.229-.512.512-.512h7.322c.283 0 .512.23.512.512v4.33c0 .283-.229.512-.511.512H6.338a.512.512 0 0 1-.512-.511ZM9.37 6.457h1.26v1.732H9.37V6.457ZM1.653 7.559h5.749v.63H1.653v-.63Zm1.181 11.89h-.787v-9.134h.787v9.134Zm8.426-9.134v5.984H3.386v-5.984h7.874Zm-7.874 7.323v-.788h7.874v.788H3.386Zm9.212 1.81h-.787v-9.133h.787v9.134Zm4.016-9.133v1.417h-3.465v-1.417h3.465Zm0 3.386h-3.465v-1.418h3.465v1.418Zm-3.465.55h3.465v1.418h-3.465v-1.417Zm0 3.387V16.22h3.465v1.418h-3.465Zm4.804 1.81h-.788v-9.133h.788v9.134Zm.984-9.684H1.063a.512.512 0 0 1 0-1.024h17.874a.512.512 0 0 1 0 1.024Z"
	                                                    fill="#000"
	                                                ></path>
	                                            </svg>
	                                        </div>
	                                        <div class="">
	                                            <svg width="1.2em" height="1.2em" viewBox="0 0 20 14" fill="none" xmlns="http://www.w3.org/2000/svg">
	                                                <path
	                                                    fill-rule="evenodd"
	                                                    clip-rule="evenodd"
	                                                    d="M.455 0A.454.454 0 0 0 0 .455v9.943c0 .25.203.454.455.454h9.093v2.016H5.302a.454.454 0 1 0 0 .91H14.7a.455.455 0 1 0 0-.91h-4.243v-2.016h9.089a.454.454 0 0 0 .454-.454V.455A.454.454 0 0 0 19.546 0H.454Zm.454.909h18.182v9.034H.91V.91Z"
	                                                    fill="#000"
	                                                ></path>
	                                            </svg>
	                                        </div>
	                                    </div>
	                                </div>
	                            </div>
	                            </a>
	                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- <div class="col-lg-6">
                            <div class="card">
                                <div id="carouselExample2" class="carousel slide" data-bs-ride="carousel">
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <img src="assest/images/luxury_img3.webp" class="d-block listing_imgs" alt="First slide" />
                                        </div>
                                        <div class="carousel-item">
                                            <img src="assest/images/luxury_img2.webp" class="d-block listing_imgs" alt="Second slide" />
                                        </div>
                                        <div class="carousel-item">
                                            <img src="assest/images/luxury_img1.webp" class="d-block listing_imgs" alt="Third slide" />
                                        </div>
                                    </div>
                                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample2" data-bs-slide="prev">
                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Previous</span>
                                    </button>
                                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample2" data-bs-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Next</span>
                                    </button>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">Villa Mare Pompano Beach</h5>
                                    <p class="card-text card_room_text">Pompano beach Florida.</p>
                                    <div class="d-flex justify-content-between">
                                        <div class="d-flex">
                                            <div class="pe-3">
                                                <div class="styles_roomsAndPrice">Bedrooms</div>
                                                <div class="property_cardvalue">5</div>
                                            </div>
                                            <div class="ps-3 border-start">
                                                <div class="styles_roomsAndPrice">Bathrooms</div>
                                                <div class="property_cardvalue">6</div>
                                            </div>
                                        </div>
                                        <div style="text-align: right;">
                                            <div class="styles_roomsAndPrice">Avg. price per 5 nights</div>
                                            <div class="property_cardvalue">$4,250</div>
                                        </div>
                                    </div>
                                    <div class="amenities">
                                        <div class="hoverable">
                                            <svg width="1.2em" height="1.2em" viewBox="0 0 22 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M10.984.801C7.026.837 3.602 2.204.744 4.958c-.112.107-.222.207-.387.19-.154-.016-.277-.096-.329-.24-.06-.167-.026-.319.11-.453A14.622 14.622 0 0 1 2.103 2.8C4.94.828 8.084-.117 11.533.01c3.996.15 7.426 1.65 10.297 4.433.206.2.225.436.057.609-.168.172-.41.159-.617-.048a14.275 14.275 0 0 0-3.183-2.392 14.5 14.5 0 0 0-6.29-1.81c-.27-.015-.54-.002-.813-.002Z"
                                                    fill="#000"
                                                ></path>
                                                <path
                                                    d="M11.02 3.13c3.326.043 6.207 1.187 8.606 3.51.16.154.222.325.11.524-.101.183-.27.224-.466.172-.078-.02-.13-.073-.183-.126-1.748-1.705-3.822-2.793-6.231-3.157-3.733-.562-7.004.454-9.791 3.013-.055.05-.109.104-.165.155-.195.178-.421.183-.58.015-.16-.168-.149-.393.037-.58.338-.342.698-.66 1.08-.952C5.6 4.046 8.043 3.188 10.77 3.13c.085-.002.167 0 .25 0Z"
                                                    fill="#000"
                                                ></path>
                                                <path
                                                    d="M10.999 6.242c2.412.043 4.516.86 6.288 2.516a.918.918 0 0 1 .234.301c.079.179.09.333-.082.46a.402.402 0 0 1-.535-.031c-.588-.605-1.27-1.08-2.01-1.477-3.16-1.698-7.164-1.13-9.727 1.38-.225.22-.455.244-.632.066s-.15-.417.091-.644C6.41 7.119 8.537 6.278 11 6.243Z"
                                                    fill="#000"
                                                ></path>
                                                <path
                                                    d="M10.983 9.37c1.601.027 2.995.57 4.168 1.67.156.145.25.305.172.518-.105.29-.443.323-.701.072-.621-.601-1.344-1.041-2.18-1.262-1.922-.508-3.628-.09-5.096 1.26-.163.15-.332.208-.529.096-.175-.098-.211-.262-.169-.449.022-.092.086-.157.15-.22 1.175-1.11 2.575-1.658 4.185-1.686ZM11.016 15.663a1.58 1.58 0 0 1-1.6-1.6 1.6 1.6 0 1 1 1.6 1.6Z"
                                                    fill="#000"
                                                ></path>
                                            </svg>
                                        </div>
                                        <div class="">
                                            <svg width="1.2em" height="1.2em" viewBox="0 0 15 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M14.444 7.778A2.779 2.779 0 0 0 11.667 5h-.556v-.556c0-.91-.755-1.666-1.667-1.666H8.89V1.11h.978a4.98 4.98 0 0 1 2.11.489.506.506 0 0 0 .245.067c.2 0 .4-.111.49-.311.132-.267.021-.6-.245-.756-.8-.378-1.69-.6-2.6-.6H4.444a.55.55 0 0 0-.555.556.55.55 0 0 0 .555.555h1.112v1.667H5c-.911 0-1.667.755-1.667 1.666V5h-.555A2.779 2.779 0 0 0 0 7.778v9.444A2.779 2.779 0 0 0 2.778 20h8.889a2.779 2.779 0 0 0 2.777-2.778V7.778ZM6.667 1.11h1.11v1.667h-1.11V1.11ZM4.444 4.444A.55.55 0 0 1 5 3.89h4.444a.55.55 0 0 1 .556.555V5H4.444v-.556Zm8.89 12.778c0 .911-.756 1.667-1.667 1.667h-8.89a1.679 1.679 0 0 1-1.666-1.667V7.778c0-.911.756-1.667 1.667-1.667h8.889c.91 0 1.666.756 1.666 1.667v9.444Z"
                                                    fill="#000"
                                                ></path>
                                            </svg>
                                        </div>
                                        <div class="">
                                            <svg width="1.2em" height="1.2em" viewBox="0 0 20 20" fill="none">
                                                <path
                                                    d="M19.583 20H.417A.417.417 0 0 1 0 19.583V16.25c0-.23.187-.417.417-.417h9.674l2.292-9.166H.417A.417.417 0 0 1 0 6.25V.417C0 .187.187 0 .417 0h19.167c.229 0 .416.187.416.417v19.166c0 .23-.187.417-.416.417Zm-18.75-.833h18.334V.834H.832v5h12.084a.414.414 0 0 1 .404.518l-2.5 10a.416.416 0 0 1-.404.315H.834v2.5Z"
                                                    fill="#000"
                                                ></path>
                                                <path
                                                    d="M5 6.667h.834v1.667H5V6.667ZM5.903 16.667H4.93a3.267 3.267 0 0 1-3.263-3.264v-2.986c0-.23.186-.417.416-.417H8.75c.23 0 .417.187.417.417v2.986c0 1.8-1.464 3.264-3.263 3.264ZM2.5 10.833v2.57c0 1.34 1.09 2.43 2.43 2.43h.973c1.34 0 2.43-1.09 2.43-2.43v-2.57H2.5Z"
                                                    fill="#000"
                                                ></path>
                                                <path
                                                    d="M2.5 14.167H1.233c-.68 0-1.233-.553-1.233-1.233v-.867c0-.68.554-1.233 1.233-1.233h.434v.834h-.434a.4.4 0 0 0-.4.399v.867c0 .22.18.4.4.4H2.5v.833ZM17.917 18.333h-3.333a.417.417 0 0 1-.417-.417V16.25c0-.23.188-.417.417-.417h3.333c.23 0 .417.187.417.417v1.666c0 .23-.188.417-.417.417ZM15 17.5h2.5v-.833H15v.833Z"
                                                    fill="#000"
                                                ></path>
                                            </svg>
                                        </div>
                                        <div class="">
                                            <svg width="1.2em" height="1.2em" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M18.666 0H8.66a1.335 1.335 0 0 0-1.334 1.334V8.37a1.96 1.96 0 0 0-1 .484 2.004 2.004 0 0 0-3.113.583 1.672 1.672 0 0 0-2.221 1.617 1.333 1.333 0 0 0 .37 2.622l.52 4.168a1.339 1.339 0 0 0 1.325 1.168c.12.008 6.975-.013 6.787 0h7.338a1.335 1.335 0 0 0 1.334-1.334v-.333A1.335 1.335 0 0 0 20 16.009V1.334A1.335 1.335 0 0 0 18.666 0ZM8.66.667h10.006a.668.668 0 0 1 .667.667V4.67h-2.001v-.334a1.003 1.003 0 0 0-1-1h-5.337a1.002 1.002 0 0 0-1.001 1v.334H7.993V1.334A.668.668 0 0 1 8.66.667Zm8.005 4.003H10.66v-.334c0-.184.15-.333.334-.333h5.336c.184 0 .334.149.334.333v.334ZM2.656 10.006c.196 0 .387.059.55.167a.333.333 0 0 0 .505-.187 1.339 1.339 0 0 1 1.28-.98c.422-.001.818.2 1.066.541a.345.345 0 0 0 .536 0 1.333 1.333 0 0 1 2.346.439.335.335 0 0 0 .506.188.988.988 0 0 1 1.256.126c.188.187.293.441.294.707H6.992a.334.334 0 0 0-.333.333v.334a.338.338 0 0 1-.334.333 1.002 1.002 0 0 0-1 1v1.168a.5.5 0 1 1-1.001 0v-1.167a1.002 1.002 0 0 0-1-1H2.99a.334.334 0 0 1-.334-.334v-.334a.334.334 0 0 0-.333-.333h-.667a1.002 1.002 0 0 1 1-1Zm4.372 2.377a.981.981 0 0 0 .298-.71h4.002a.667.667 0 0 1 0 1.335H5.992c0-.184.149-.333.333-.334a.975.975 0 0 0 .703-.29Zm4.63-1.33a1.65 1.65 0 0 0-.674-1.38c1.43-2.81 5.65-1.825 5.68 1.334a3.015 3.015 0 0 1-4.68 2.489 1.331 1.331 0 0 0-.325-2.443Zm-.383 2.735c2.329 2.044 6.08.32 6.056-2.781-.052-3.88-5.202-5.064-6.958-1.62a1.542 1.542 0 0 0-.728-.006c1.85-4.364 8.275-3.136 8.354 1.626.045 3.452-4.026 5.576-6.82 3.547l.096-.766ZM.655 12.341a.672.672 0 0 1 .667-.667h.667a1.002 1.002 0 0 0 1 1h.334c.184 0 .333.15.334.334H1.322a.668.668 0 0 1-.667-.667Zm1.888 5.418-.51-4.084h1.624v.5a1.168 1.168 0 0 0 2.334 0v-.5h4.626l-.51 4.084a.67.67 0 0 1-.664.585H3.206a.67.67 0 0 1-.663-.585ZM18 17.677a.668.668 0 0 1-.668.667h-6.736c.146-.314.227-.654.236-1h7.168v.333Zm.667-1h-7.752l.173-1.386c3.247 2.026 7.63-.454 7.579-4.285-.081-5.395-7.302-6.908-9.566-2.043a1.998 1.998 0 0 0-1.107-.593V5.337h11.34V16.01a.668.668 0 0 1-.667.667Z"
                                                    fill="#000"
                                                ></path>
                                                <path
                                                    d="M15.664 3.002a1 1 0 0 0 0-2.001 1 1 0 0 0 0 2.001Zm0-1.334a.334.334 0 0 1 0 .667.334.334 0 0 1 0-.667ZM17.999 3.002a1 1 0 0 0 0-2.001 1 1 0 0 0 0 2.001Zm0-1.334a.334.334 0 0 1 0 .667.334.334 0 0 1 0-.667ZM4.991 15.676a1.001 1.001 0 0 0 0 2.001 1 1 0 0 0 0-2Zm0 1.335a.334.334 0 0 1 0-.668.334.334 0 0 1 0 .668Z"
                                                    fill="#000"
                                                ></path>
                                            </svg>
                                        </div>
                                        <div class="">
                                            <svg width="1.2em" height="1.2em" viewBox="0 0 20 12" fill="none">
                                                <path
                                                    d="M1.504 8.662h.201v2.168c0 .139.112.251.25.251h2.012a.25.25 0 00.25-.25V8.661h1.936v1.236c0 .138.112.25.25.25h9.38v.682c0 .139.112.251.25.251h2.011a.25.25 0 00.25-.25V8.661h.202c.83 0 1.504-.675 1.504-1.504 0-.83-.675-1.504-1.504-1.504h-.912v-.157c0-.588-.479-1.067-1.067-1.067H7.22c-.589 0-1.067.479-1.067 1.067v.157h-.927V2.83a.937.937 0 00-.936-.936H3.008v-.39C3.008.674 2.333 0 1.504 0 .674 0 0 .675 0 1.504v5.654c0 .83.675 1.504 1.504 1.504zm16.08-2.507h.912a1.004 1.004 0 010 2.006h-.912V6.155zm-.251 3.993a.25.25 0 00.25-.25V8.662h.21v1.918h-1.51v-.432h1.05zM6.654 5.497c0-.312.254-.566.565-.566h9.298c.312 0 .565.254.565.566v4.15H6.654v-4.15zM3.716 10.58h-1.51V8.662h1.51v1.918zm-.708-8.184H4.29c.24 0 .435.195.435.434v2.824H3.008V2.396zM.5 1.504a1.004 1.004 0 012.006 0v4.4c0 .14.112.251.25.251h3.396v2.006H1.504C.951 8.16.502 7.71.502 7.158V1.504z"
                                                    fill="#000"
                                                ></path>
                                            </svg>
                                        </div>
                                        <div class="">
                                            <svg width="1.2em" height="1.2em" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M18.937 8.189h-4.213v-.906a.276.276 0 0 0-.275-.275h-1.772a.276.276 0 0 0-.275.275v.906h-1.22V6.457h2.48a1.063 1.063 0 0 0 1.063-1.063V1.063A1.063 1.063 0 0 0 13.662 0H6.338a1.063 1.063 0 0 0-1.063 1.063v4.33a1.063 1.063 0 0 0 1.063 1.064h2.48v1.732h-.866v-.906a.275.275 0 0 0-.276-.275H1.378a.276.276 0 0 0-.276.275v.906h-.039a1.063 1.063 0 1 0 0 2.126h.433v9.41c0 .152.124.275.276.275H3.11a.276.276 0 0 0 .276-.276V18.19h7.874v1.535c0 .153.123.276.275.276h1.339a.276.276 0 0 0 .276-.276V18.19h3.464v1.535c0 .153.124.276.276.276h1.338a.276.276 0 0 0 .276-.276v-9.41h.433a1.063 1.063 0 0 0 0-2.125Zm-5.984-.63h1.22v.63h-1.22v-.63ZM5.827 5.394V1.063c0-.283.229-.512.512-.512h7.322c.283 0 .512.23.512.512v4.33c0 .283-.229.512-.511.512H6.338a.512.512 0 0 1-.512-.511ZM9.37 6.457h1.26v1.732H9.37V6.457ZM1.653 7.559h5.749v.63H1.653v-.63Zm1.181 11.89h-.787v-9.134h.787v9.134Zm8.426-9.134v5.984H3.386v-5.984h7.874Zm-7.874 7.323v-.788h7.874v.788H3.386Zm9.212 1.81h-.787v-9.133h.787v9.134Zm4.016-9.133v1.417h-3.465v-1.417h3.465Zm0 3.386h-3.465v-1.418h3.465v1.418Zm-3.465.55h3.465v1.418h-3.465v-1.417Zm0 3.387V16.22h3.465v1.418h-3.465Zm4.804 1.81h-.788v-9.133h.788v9.134Zm.984-9.684H1.063a.512.512 0 0 1 0-1.024h17.874a.512.512 0 0 1 0 1.024Z"
                                                    fill="#000"
                                                ></path>
                                            </svg>
                                        </div>
                                        <div class="">
                                            <svg width="1.2em" height="1.2em" viewBox="0 0 20 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    fill-rule="evenodd"
                                                    clip-rule="evenodd"
                                                    d="M.455 0A.454.454 0 0 0 0 .455v9.943c0 .25.203.454.455.454h9.093v2.016H5.302a.454.454 0 1 0 0 .91H14.7a.455.455 0 1 0 0-.91h-4.243v-2.016h9.089a.454.454 0 0 0 .454-.454V.455A.454.454 0 0 0 19.546 0H.454Zm.454.909h18.182v9.034H.91V.91Z"
                                                    fill="#000"
                                                ></path>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="card">
                                <div id="carouselExample3" class="carousel slide" data-bs-ride="carousel">
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <img src="assest/images/luxury_img3.webp" class="d-block listing_imgs" alt="First slide" />
                                        </div>
                                        <div class="carousel-item">
                                            <img src="assest/images/luxury_img2.webp" class="d-block listing_imgs" alt="Second slide" />
                                        </div>
                                        <div class="carousel-item">
                                            <img src="assest/images/luxury_img1.webp" class="d-block listing_imgs" alt="Third slide" />
                                        </div>
                                    </div>
                                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample3" data-bs-slide="prev">
                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Previous</span>
                                    </button>
                                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample3" data-bs-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Next</span>
                                    </button>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">Villa Mare Pompano Beach</h5>
                                    <p class="card-text card_room_text">Pompano beach Florida.</p>
                                    <div class="d-flex justify-content-between">
                                        <div class="d-flex">
                                            <div class="pe-3">
                                                <div class="styles_roomsAndPrice">Bedrooms</div>
                                                <div class="property_cardvalue">5</div>
                                            </div>
                                            <div class="ps-3 border-start">
                                                <div class="styles_roomsAndPrice">Bathrooms</div>
                                                <div class="property_cardvalue">6</div>
                                            </div>
                                        </div>
                                        <div style="text-align: right;">
                                            <div class="styles_roomsAndPrice">Avg. price per 5 nights</div>
                                            <div class="property_cardvalue">$4,250</div>
                                        </div>
                                    </div>
                                    <div class="amenities">
                                        <div class="hoverable">
                                            <svg width="1.2em" height="1.2em" viewBox="0 0 22 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M10.984.801C7.026.837 3.602 2.204.744 4.958c-.112.107-.222.207-.387.19-.154-.016-.277-.096-.329-.24-.06-.167-.026-.319.11-.453A14.622 14.622 0 0 1 2.103 2.8C4.94.828 8.084-.117 11.533.01c3.996.15 7.426 1.65 10.297 4.433.206.2.225.436.057.609-.168.172-.41.159-.617-.048a14.275 14.275 0 0 0-3.183-2.392 14.5 14.5 0 0 0-6.29-1.81c-.27-.015-.54-.002-.813-.002Z"
                                                    fill="#000"
                                                ></path>
                                                <path
                                                    d="M11.02 3.13c3.326.043 6.207 1.187 8.606 3.51.16.154.222.325.11.524-.101.183-.27.224-.466.172-.078-.02-.13-.073-.183-.126-1.748-1.705-3.822-2.793-6.231-3.157-3.733-.562-7.004.454-9.791 3.013-.055.05-.109.104-.165.155-.195.178-.421.183-.58.015-.16-.168-.149-.393.037-.58.338-.342.698-.66 1.08-.952C5.6 4.046 8.043 3.188 10.77 3.13c.085-.002.167 0 .25 0Z"
                                                    fill="#000"
                                                ></path>
                                                <path
                                                    d="M10.999 6.242c2.412.043 4.516.86 6.288 2.516a.918.918 0 0 1 .234.301c.079.179.09.333-.082.46a.402.402 0 0 1-.535-.031c-.588-.605-1.27-1.08-2.01-1.477-3.16-1.698-7.164-1.13-9.727 1.38-.225.22-.455.244-.632.066s-.15-.417.091-.644C6.41 7.119 8.537 6.278 11 6.243Z"
                                                    fill="#000"
                                                ></path>
                                                <path
                                                    d="M10.983 9.37c1.601.027 2.995.57 4.168 1.67.156.145.25.305.172.518-.105.29-.443.323-.701.072-.621-.601-1.344-1.041-2.18-1.262-1.922-.508-3.628-.09-5.096 1.26-.163.15-.332.208-.529.096-.175-.098-.211-.262-.169-.449.022-.092.086-.157.15-.22 1.175-1.11 2.575-1.658 4.185-1.686ZM11.016 15.663a1.58 1.58 0 0 1-1.6-1.6 1.6 1.6 0 1 1 1.6 1.6Z"
                                                    fill="#000"
                                                ></path>
                                            </svg>
                                        </div>
                                        <div class="">
                                            <svg width="1.2em" height="1.2em" viewBox="0 0 15 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M14.444 7.778A2.779 2.779 0 0 0 11.667 5h-.556v-.556c0-.91-.755-1.666-1.667-1.666H8.89V1.11h.978a4.98 4.98 0 0 1 2.11.489.506.506 0 0 0 .245.067c.2 0 .4-.111.49-.311.132-.267.021-.6-.245-.756-.8-.378-1.69-.6-2.6-.6H4.444a.55.55 0 0 0-.555.556.55.55 0 0 0 .555.555h1.112v1.667H5c-.911 0-1.667.755-1.667 1.666V5h-.555A2.779 2.779 0 0 0 0 7.778v9.444A2.779 2.779 0 0 0 2.778 20h8.889a2.779 2.779 0 0 0 2.777-2.778V7.778ZM6.667 1.11h1.11v1.667h-1.11V1.11ZM4.444 4.444A.55.55 0 0 1 5 3.89h4.444a.55.55 0 0 1 .556.555V5H4.444v-.556Zm8.89 12.778c0 .911-.756 1.667-1.667 1.667h-8.89a1.679 1.679 0 0 1-1.666-1.667V7.778c0-.911.756-1.667 1.667-1.667h8.889c.91 0 1.666.756 1.666 1.667v9.444Z"
                                                    fill="#000"
                                                ></path>
                                            </svg>
                                        </div>
                                        <div class="">
                                            <svg width="1.2em" height="1.2em" viewBox="0 0 20 20" fill="none">
                                                <path
                                                    d="M19.583 20H.417A.417.417 0 0 1 0 19.583V16.25c0-.23.187-.417.417-.417h9.674l2.292-9.166H.417A.417.417 0 0 1 0 6.25V.417C0 .187.187 0 .417 0h19.167c.229 0 .416.187.416.417v19.166c0 .23-.187.417-.416.417Zm-18.75-.833h18.334V.834H.832v5h12.084a.414.414 0 0 1 .404.518l-2.5 10a.416.416 0 0 1-.404.315H.834v2.5Z"
                                                    fill="#000"
                                                ></path>
                                                <path
                                                    d="M5 6.667h.834v1.667H5V6.667ZM5.903 16.667H4.93a3.267 3.267 0 0 1-3.263-3.264v-2.986c0-.23.186-.417.416-.417H8.75c.23 0 .417.187.417.417v2.986c0 1.8-1.464 3.264-3.263 3.264ZM2.5 10.833v2.57c0 1.34 1.09 2.43 2.43 2.43h.973c1.34 0 2.43-1.09 2.43-2.43v-2.57H2.5Z"
                                                    fill="#000"
                                                ></path>
                                                <path
                                                    d="M2.5 14.167H1.233c-.68 0-1.233-.553-1.233-1.233v-.867c0-.68.554-1.233 1.233-1.233h.434v.834h-.434a.4.4 0 0 0-.4.399v.867c0 .22.18.4.4.4H2.5v.833ZM17.917 18.333h-3.333a.417.417 0 0 1-.417-.417V16.25c0-.23.188-.417.417-.417h3.333c.23 0 .417.187.417.417v1.666c0 .23-.188.417-.417.417ZM15 17.5h2.5v-.833H15v.833Z"
                                                    fill="#000"
                                                ></path>
                                            </svg>
                                        </div>
                                        <div class="">
                                            <svg width="1.2em" height="1.2em" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M18.666 0H8.66a1.335 1.335 0 0 0-1.334 1.334V8.37a1.96 1.96 0 0 0-1 .484 2.004 2.004 0 0 0-3.113.583 1.672 1.672 0 0 0-2.221 1.617 1.333 1.333 0 0 0 .37 2.622l.52 4.168a1.339 1.339 0 0 0 1.325 1.168c.12.008 6.975-.013 6.787 0h7.338a1.335 1.335 0 0 0 1.334-1.334v-.333A1.335 1.335 0 0 0 20 16.009V1.334A1.335 1.335 0 0 0 18.666 0ZM8.66.667h10.006a.668.668 0 0 1 .667.667V4.67h-2.001v-.334a1.003 1.003 0 0 0-1-1h-5.337a1.002 1.002 0 0 0-1.001 1v.334H7.993V1.334A.668.668 0 0 1 8.66.667Zm8.005 4.003H10.66v-.334c0-.184.15-.333.334-.333h5.336c.184 0 .334.149.334.333v.334ZM2.656 10.006c.196 0 .387.059.55.167a.333.333 0 0 0 .505-.187 1.339 1.339 0 0 1 1.28-.98c.422-.001.818.2 1.066.541a.345.345 0 0 0 .536 0 1.333 1.333 0 0 1 2.346.439.335.335 0 0 0 .506.188.988.988 0 0 1 1.256.126c.188.187.293.441.294.707H6.992a.334.334 0 0 0-.333.333v.334a.338.338 0 0 1-.334.333 1.002 1.002 0 0 0-1 1v1.168a.5.5 0 1 1-1.001 0v-1.167a1.002 1.002 0 0 0-1-1H2.99a.334.334 0 0 1-.334-.334v-.334a.334.334 0 0 0-.333-.333h-.667a1.002 1.002 0 0 1 1-1Zm4.372 2.377a.981.981 0 0 0 .298-.71h4.002a.667.667 0 0 1 0 1.335H5.992c0-.184.149-.333.333-.334a.975.975 0 0 0 .703-.29Zm4.63-1.33a1.65 1.65 0 0 0-.674-1.38c1.43-2.81 5.65-1.825 5.68 1.334a3.015 3.015 0 0 1-4.68 2.489 1.331 1.331 0 0 0-.325-2.443Zm-.383 2.735c2.329 2.044 6.08.32 6.056-2.781-.052-3.88-5.202-5.064-6.958-1.62a1.542 1.542 0 0 0-.728-.006c1.85-4.364 8.275-3.136 8.354 1.626.045 3.452-4.026 5.576-6.82 3.547l.096-.766ZM.655 12.341a.672.672 0 0 1 .667-.667h.667a1.002 1.002 0 0 0 1 1h.334c.184 0 .333.15.334.334H1.322a.668.668 0 0 1-.667-.667Zm1.888 5.418-.51-4.084h1.624v.5a1.168 1.168 0 0 0 2.334 0v-.5h4.626l-.51 4.084a.67.67 0 0 1-.664.585H3.206a.67.67 0 0 1-.663-.585ZM18 17.677a.668.668 0 0 1-.668.667h-6.736c.146-.314.227-.654.236-1h7.168v.333Zm.667-1h-7.752l.173-1.386c3.247 2.026 7.63-.454 7.579-4.285-.081-5.395-7.302-6.908-9.566-2.043a1.998 1.998 0 0 0-1.107-.593V5.337h11.34V16.01a.668.668 0 0 1-.667.667Z"
                                                    fill="#000"
                                                ></path>
                                                <path
                                                    d="M15.664 3.002a1 1 0 0 0 0-2.001 1 1 0 0 0 0 2.001Zm0-1.334a.334.334 0 0 1 0 .667.334.334 0 0 1 0-.667ZM17.999 3.002a1 1 0 0 0 0-2.001 1 1 0 0 0 0 2.001Zm0-1.334a.334.334 0 0 1 0 .667.334.334 0 0 1 0-.667ZM4.991 15.676a1.001 1.001 0 0 0 0 2.001 1 1 0 0 0 0-2Zm0 1.335a.334.334 0 0 1 0-.668.334.334 0 0 1 0 .668Z"
                                                    fill="#000"
                                                ></path>
                                            </svg>
                                        </div>
                                        <div class="">
                                            <svg width="1.2em" height="1.2em" viewBox="0 0 20 12" fill="none">
                                                <path
                                                    d="M1.504 8.662h.201v2.168c0 .139.112.251.25.251h2.012a.25.25 0 00.25-.25V8.661h1.936v1.236c0 .138.112.25.25.25h9.38v.682c0 .139.112.251.25.251h2.011a.25.25 0 00.25-.25V8.661h.202c.83 0 1.504-.675 1.504-1.504 0-.83-.675-1.504-1.504-1.504h-.912v-.157c0-.588-.479-1.067-1.067-1.067H7.22c-.589 0-1.067.479-1.067 1.067v.157h-.927V2.83a.937.937 0 00-.936-.936H3.008v-.39C3.008.674 2.333 0 1.504 0 .674 0 0 .675 0 1.504v5.654c0 .83.675 1.504 1.504 1.504zm16.08-2.507h.912a1.004 1.004 0 010 2.006h-.912V6.155zm-.251 3.993a.25.25 0 00.25-.25V8.662h.21v1.918h-1.51v-.432h1.05zM6.654 5.497c0-.312.254-.566.565-.566h9.298c.312 0 .565.254.565.566v4.15H6.654v-4.15zM3.716 10.58h-1.51V8.662h1.51v1.918zm-.708-8.184H4.29c.24 0 .435.195.435.434v2.824H3.008V2.396zM.5 1.504a1.004 1.004 0 012.006 0v4.4c0 .14.112.251.25.251h3.396v2.006H1.504C.951 8.16.502 7.71.502 7.158V1.504z"
                                                    fill="#000"
                                                ></path>
                                            </svg>
                                        </div>
                                        <div class="">
                                            <svg width="1.2em" height="1.2em" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M18.937 8.189h-4.213v-.906a.276.276 0 0 0-.275-.275h-1.772a.276.276 0 0 0-.275.275v.906h-1.22V6.457h2.48a1.063 1.063 0 0 0 1.063-1.063V1.063A1.063 1.063 0 0 0 13.662 0H6.338a1.063 1.063 0 0 0-1.063 1.063v4.33a1.063 1.063 0 0 0 1.063 1.064h2.48v1.732h-.866v-.906a.275.275 0 0 0-.276-.275H1.378a.276.276 0 0 0-.276.275v.906h-.039a1.063 1.063 0 1 0 0 2.126h.433v9.41c0 .152.124.275.276.275H3.11a.276.276 0 0 0 .276-.276V18.19h7.874v1.535c0 .153.123.276.275.276h1.339a.276.276 0 0 0 .276-.276V18.19h3.464v1.535c0 .153.124.276.276.276h1.338a.276.276 0 0 0 .276-.276v-9.41h.433a1.063 1.063 0 0 0 0-2.125Zm-5.984-.63h1.22v.63h-1.22v-.63ZM5.827 5.394V1.063c0-.283.229-.512.512-.512h7.322c.283 0 .512.23.512.512v4.33c0 .283-.229.512-.511.512H6.338a.512.512 0 0 1-.512-.511ZM9.37 6.457h1.26v1.732H9.37V6.457ZM1.653 7.559h5.749v.63H1.653v-.63Zm1.181 11.89h-.787v-9.134h.787v9.134Zm8.426-9.134v5.984H3.386v-5.984h7.874Zm-7.874 7.323v-.788h7.874v.788H3.386Zm9.212 1.81h-.787v-9.133h.787v9.134Zm4.016-9.133v1.417h-3.465v-1.417h3.465Zm0 3.386h-3.465v-1.418h3.465v1.418Zm-3.465.55h3.465v1.418h-3.465v-1.417Zm0 3.387V16.22h3.465v1.418h-3.465Zm4.804 1.81h-.788v-9.133h.788v9.134Zm.984-9.684H1.063a.512.512 0 0 1 0-1.024h17.874a.512.512 0 0 1 0 1.024Z"
                                                    fill="#000"
                                                ></path>
                                            </svg>
                                        </div>
                                        <div class="">
                                            <svg width="1.2em" height="1.2em" viewBox="0 0 20 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    fill-rule="evenodd"
                                                    clip-rule="evenodd"
                                                    d="M.455 0A.454.454 0 0 0 0 .455v9.943c0 .25.203.454.455.454h9.093v2.016H5.302a.454.454 0 1 0 0 .91H14.7a.455.455 0 1 0 0-.91h-4.243v-2.016h9.089a.454.454 0 0 0 .454-.454V.455A.454.454 0 0 0 19.546 0H.454Zm.454.909h18.182v9.034H.91V.91Z"
                                                    fill="#000"
                                                ></path>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="card">
                                <div id="carouselExample4" class="carousel slide" data-bs-ride="carousel">
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <img src="assest/images/luxury_img3.webp" class="d-block listing_imgs" alt="First slide" />
                                        </div>
                                        <div class="carousel-item">
                                            <img src="assest/images/luxury_img2.webp" class="d-block listing_imgs" alt="Second slide" />
                                        </div>
                                        <div class="carousel-item">
                                            <img src="assest/images/luxury_img1.webp" class="d-block listing_imgs" alt="Third slide" />
                                        </div>
                                    </div>
                                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample4" data-bs-slide="prev">
                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Previous</span>
                                    </button>
                                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample4" data-bs-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Next</span>
                                    </button>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">Villa Mare Pompano Beach</h5>
                                    <p class="card-text card_room_text">Pompano beach Florida.</p>
                                    <div class="d-flex justify-content-between">
                                        <div class="d-flex">
                                            <div class="pe-3">
                                                <div class="styles_roomsAndPrice">Bedrooms</div>
                                                <div class="property_cardvalue">5</div>
                                            </div>
                                            <div class="ps-3 border-start">
                                                <div class="styles_roomsAndPrice">Bathrooms</div>
                                                <div class="property_cardvalue">6</div>
                                            </div>
                                        </div>
                                        <div style="text-align: right;">
                                            <div class="styles_roomsAndPrice">Avg. price per 5 nights</div>
                                            <div class="property_cardvalue">$4,250</div>
                                        </div>
                                    </div>
                                    <div class="amenities">
                                        <div class="hoverable">
                                            <svg width="1.2em" height="1.2em" viewBox="0 0 22 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M10.984.801C7.026.837 3.602 2.204.744 4.958c-.112.107-.222.207-.387.19-.154-.016-.277-.096-.329-.24-.06-.167-.026-.319.11-.453A14.622 14.622 0 0 1 2.103 2.8C4.94.828 8.084-.117 11.533.01c3.996.15 7.426 1.65 10.297 4.433.206.2.225.436.057.609-.168.172-.41.159-.617-.048a14.275 14.275 0 0 0-3.183-2.392 14.5 14.5 0 0 0-6.29-1.81c-.27-.015-.54-.002-.813-.002Z"
                                                    fill="#000"
                                                ></path>
                                                <path
                                                    d="M11.02 3.13c3.326.043 6.207 1.187 8.606 3.51.16.154.222.325.11.524-.101.183-.27.224-.466.172-.078-.02-.13-.073-.183-.126-1.748-1.705-3.822-2.793-6.231-3.157-3.733-.562-7.004.454-9.791 3.013-.055.05-.109.104-.165.155-.195.178-.421.183-.58.015-.16-.168-.149-.393.037-.58.338-.342.698-.66 1.08-.952C5.6 4.046 8.043 3.188 10.77 3.13c.085-.002.167 0 .25 0Z"
                                                    fill="#000"
                                                ></path>
                                                <path
                                                    d="M10.999 6.242c2.412.043 4.516.86 6.288 2.516a.918.918 0 0 1 .234.301c.079.179.09.333-.082.46a.402.402 0 0 1-.535-.031c-.588-.605-1.27-1.08-2.01-1.477-3.16-1.698-7.164-1.13-9.727 1.38-.225.22-.455.244-.632.066s-.15-.417.091-.644C6.41 7.119 8.537 6.278 11 6.243Z"
                                                    fill="#000"
                                                ></path>
                                                <path
                                                    d="M10.983 9.37c1.601.027 2.995.57 4.168 1.67.156.145.25.305.172.518-.105.29-.443.323-.701.072-.621-.601-1.344-1.041-2.18-1.262-1.922-.508-3.628-.09-5.096 1.26-.163.15-.332.208-.529.096-.175-.098-.211-.262-.169-.449.022-.092.086-.157.15-.22 1.175-1.11 2.575-1.658 4.185-1.686ZM11.016 15.663a1.58 1.58 0 0 1-1.6-1.6 1.6 1.6 0 1 1 1.6 1.6Z"
                                                    fill="#000"
                                                ></path>
                                            </svg>
                                        </div>
                                        <div class="">
                                            <svg width="1.2em" height="1.2em" viewBox="0 0 15 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M14.444 7.778A2.779 2.779 0 0 0 11.667 5h-.556v-.556c0-.91-.755-1.666-1.667-1.666H8.89V1.11h.978a4.98 4.98 0 0 1 2.11.489.506.506 0 0 0 .245.067c.2 0 .4-.111.49-.311.132-.267.021-.6-.245-.756-.8-.378-1.69-.6-2.6-.6H4.444a.55.55 0 0 0-.555.556.55.55 0 0 0 .555.555h1.112v1.667H5c-.911 0-1.667.755-1.667 1.666V5h-.555A2.779 2.779 0 0 0 0 7.778v9.444A2.779 2.779 0 0 0 2.778 20h8.889a2.779 2.779 0 0 0 2.777-2.778V7.778ZM6.667 1.11h1.11v1.667h-1.11V1.11ZM4.444 4.444A.55.55 0 0 1 5 3.89h4.444a.55.55 0 0 1 .556.555V5H4.444v-.556Zm8.89 12.778c0 .911-.756 1.667-1.667 1.667h-8.89a1.679 1.679 0 0 1-1.666-1.667V7.778c0-.911.756-1.667 1.667-1.667h8.889c.91 0 1.666.756 1.666 1.667v9.444Z"
                                                    fill="#000"
                                                ></path>
                                            </svg>
                                        </div>
                                        <div class="">
                                            <svg width="1.2em" height="1.2em" viewBox="0 0 20 20" fill="none">
                                                <path
                                                    d="M19.583 20H.417A.417.417 0 0 1 0 19.583V16.25c0-.23.187-.417.417-.417h9.674l2.292-9.166H.417A.417.417 0 0 1 0 6.25V.417C0 .187.187 0 .417 0h19.167c.229 0 .416.187.416.417v19.166c0 .23-.187.417-.416.417Zm-18.75-.833h18.334V.834H.832v5h12.084a.414.414 0 0 1 .404.518l-2.5 10a.416.416 0 0 1-.404.315H.834v2.5Z"
                                                    fill="#000"
                                                ></path>
                                                <path
                                                    d="M5 6.667h.834v1.667H5V6.667ZM5.903 16.667H4.93a3.267 3.267 0 0 1-3.263-3.264v-2.986c0-.23.186-.417.416-.417H8.75c.23 0 .417.187.417.417v2.986c0 1.8-1.464 3.264-3.263 3.264ZM2.5 10.833v2.57c0 1.34 1.09 2.43 2.43 2.43h.973c1.34 0 2.43-1.09 2.43-2.43v-2.57H2.5Z"
                                                    fill="#000"
                                                ></path>
                                                <path
                                                    d="M2.5 14.167H1.233c-.68 0-1.233-.553-1.233-1.233v-.867c0-.68.554-1.233 1.233-1.233h.434v.834h-.434a.4.4 0 0 0-.4.399v.867c0 .22.18.4.4.4H2.5v.833ZM17.917 18.333h-3.333a.417.417 0 0 1-.417-.417V16.25c0-.23.188-.417.417-.417h3.333c.23 0 .417.187.417.417v1.666c0 .23-.188.417-.417.417ZM15 17.5h2.5v-.833H15v.833Z"
                                                    fill="#000"
                                                ></path>
                                            </svg>
                                        </div>
                                        <div class="">
                                            <svg width="1.2em" height="1.2em" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M18.666 0H8.66a1.335 1.335 0 0 0-1.334 1.334V8.37a1.96 1.96 0 0 0-1 .484 2.004 2.004 0 0 0-3.113.583 1.672 1.672 0 0 0-2.221 1.617 1.333 1.333 0 0 0 .37 2.622l.52 4.168a1.339 1.339 0 0 0 1.325 1.168c.12.008 6.975-.013 6.787 0h7.338a1.335 1.335 0 0 0 1.334-1.334v-.333A1.335 1.335 0 0 0 20 16.009V1.334A1.335 1.335 0 0 0 18.666 0ZM8.66.667h10.006a.668.668 0 0 1 .667.667V4.67h-2.001v-.334a1.003 1.003 0 0 0-1-1h-5.337a1.002 1.002 0 0 0-1.001 1v.334H7.993V1.334A.668.668 0 0 1 8.66.667Zm8.005 4.003H10.66v-.334c0-.184.15-.333.334-.333h5.336c.184 0 .334.149.334.333v.334ZM2.656 10.006c.196 0 .387.059.55.167a.333.333 0 0 0 .505-.187 1.339 1.339 0 0 1 1.28-.98c.422-.001.818.2 1.066.541a.345.345 0 0 0 .536 0 1.333 1.333 0 0 1 2.346.439.335.335 0 0 0 .506.188.988.988 0 0 1 1.256.126c.188.187.293.441.294.707H6.992a.334.334 0 0 0-.333.333v.334a.338.338 0 0 1-.334.333 1.002 1.002 0 0 0-1 1v1.168a.5.5 0 1 1-1.001 0v-1.167a1.002 1.002 0 0 0-1-1H2.99a.334.334 0 0 1-.334-.334v-.334a.334.334 0 0 0-.333-.333h-.667a1.002 1.002 0 0 1 1-1Zm4.372 2.377a.981.981 0 0 0 .298-.71h4.002a.667.667 0 0 1 0 1.335H5.992c0-.184.149-.333.333-.334a.975.975 0 0 0 .703-.29Zm4.63-1.33a1.65 1.65 0 0 0-.674-1.38c1.43-2.81 5.65-1.825 5.68 1.334a3.015 3.015 0 0 1-4.68 2.489 1.331 1.331 0 0 0-.325-2.443Zm-.383 2.735c2.329 2.044 6.08.32 6.056-2.781-.052-3.88-5.202-5.064-6.958-1.62a1.542 1.542 0 0 0-.728-.006c1.85-4.364 8.275-3.136 8.354 1.626.045 3.452-4.026 5.576-6.82 3.547l.096-.766ZM.655 12.341a.672.672 0 0 1 .667-.667h.667a1.002 1.002 0 0 0 1 1h.334c.184 0 .333.15.334.334H1.322a.668.668 0 0 1-.667-.667Zm1.888 5.418-.51-4.084h1.624v.5a1.168 1.168 0 0 0 2.334 0v-.5h4.626l-.51 4.084a.67.67 0 0 1-.664.585H3.206a.67.67 0 0 1-.663-.585ZM18 17.677a.668.668 0 0 1-.668.667h-6.736c.146-.314.227-.654.236-1h7.168v.333Zm.667-1h-7.752l.173-1.386c3.247 2.026 7.63-.454 7.579-4.285-.081-5.395-7.302-6.908-9.566-2.043a1.998 1.998 0 0 0-1.107-.593V5.337h11.34V16.01a.668.668 0 0 1-.667.667Z"
                                                    fill="#000"
                                                ></path>
                                                <path
                                                    d="M15.664 3.002a1 1 0 0 0 0-2.001 1 1 0 0 0 0 2.001Zm0-1.334a.334.334 0 0 1 0 .667.334.334 0 0 1 0-.667ZM17.999 3.002a1 1 0 0 0 0-2.001 1 1 0 0 0 0 2.001Zm0-1.334a.334.334 0 0 1 0 .667.334.334 0 0 1 0-.667ZM4.991 15.676a1.001 1.001 0 0 0 0 2.001 1 1 0 0 0 0-2Zm0 1.335a.334.334 0 0 1 0-.668.334.334 0 0 1 0 .668Z"
                                                    fill="#000"
                                                ></path>
                                            </svg>
                                        </div>
                                        <div class="">
                                            <svg width="1.2em" height="1.2em" viewBox="0 0 20 12" fill="none">
                                                <path
                                                    d="M1.504 8.662h.201v2.168c0 .139.112.251.25.251h2.012a.25.25 0 00.25-.25V8.661h1.936v1.236c0 .138.112.25.25.25h9.38v.682c0 .139.112.251.25.251h2.011a.25.25 0 00.25-.25V8.661h.202c.83 0 1.504-.675 1.504-1.504 0-.83-.675-1.504-1.504-1.504h-.912v-.157c0-.588-.479-1.067-1.067-1.067H7.22c-.589 0-1.067.479-1.067 1.067v.157h-.927V2.83a.937.937 0 00-.936-.936H3.008v-.39C3.008.674 2.333 0 1.504 0 .674 0 0 .675 0 1.504v5.654c0 .83.675 1.504 1.504 1.504zm16.08-2.507h.912a1.004 1.004 0 010 2.006h-.912V6.155zm-.251 3.993a.25.25 0 00.25-.25V8.662h.21v1.918h-1.51v-.432h1.05zM6.654 5.497c0-.312.254-.566.565-.566h9.298c.312 0 .565.254.565.566v4.15H6.654v-4.15zM3.716 10.58h-1.51V8.662h1.51v1.918zm-.708-8.184H4.29c.24 0 .435.195.435.434v2.824H3.008V2.396zM.5 1.504a1.004 1.004 0 012.006 0v4.4c0 .14.112.251.25.251h3.396v2.006H1.504C.951 8.16.502 7.71.502 7.158V1.504z"
                                                    fill="#000"
                                                ></path>
                                            </svg>
                                        </div>
                                        <div class="">
                                            <svg width="1.2em" height="1.2em" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M18.937 8.189h-4.213v-.906a.276.276 0 0 0-.275-.275h-1.772a.276.276 0 0 0-.275.275v.906h-1.22V6.457h2.48a1.063 1.063 0 0 0 1.063-1.063V1.063A1.063 1.063 0 0 0 13.662 0H6.338a1.063 1.063 0 0 0-1.063 1.063v4.33a1.063 1.063 0 0 0 1.063 1.064h2.48v1.732h-.866v-.906a.275.275 0 0 0-.276-.275H1.378a.276.276 0 0 0-.276.275v.906h-.039a1.063 1.063 0 1 0 0 2.126h.433v9.41c0 .152.124.275.276.275H3.11a.276.276 0 0 0 .276-.276V18.19h7.874v1.535c0 .153.123.276.275.276h1.339a.276.276 0 0 0 .276-.276V18.19h3.464v1.535c0 .153.124.276.276.276h1.338a.276.276 0 0 0 .276-.276v-9.41h.433a1.063 1.063 0 0 0 0-2.125Zm-5.984-.63h1.22v.63h-1.22v-.63ZM5.827 5.394V1.063c0-.283.229-.512.512-.512h7.322c.283 0 .512.23.512.512v4.33c0 .283-.229.512-.511.512H6.338a.512.512 0 0 1-.512-.511ZM9.37 6.457h1.26v1.732H9.37V6.457ZM1.653 7.559h5.749v.63H1.653v-.63Zm1.181 11.89h-.787v-9.134h.787v9.134Zm8.426-9.134v5.984H3.386v-5.984h7.874Zm-7.874 7.323v-.788h7.874v.788H3.386Zm9.212 1.81h-.787v-9.133h.787v9.134Zm4.016-9.133v1.417h-3.465v-1.417h3.465Zm0 3.386h-3.465v-1.418h3.465v1.418Zm-3.465.55h3.465v1.418h-3.465v-1.417Zm0 3.387V16.22h3.465v1.418h-3.465Zm4.804 1.81h-.788v-9.133h.788v9.134Zm.984-9.684H1.063a.512.512 0 0 1 0-1.024h17.874a.512.512 0 0 1 0 1.024Z"
                                                    fill="#000"
                                                ></path>
                                            </svg>
                                        </div>
                                        <div class="">
                                            <svg width="1.2em" height="1.2em" viewBox="0 0 20 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    fill-rule="evenodd"
                                                    clip-rule="evenodd"
                                                    d="M.455 0A.454.454 0 0 0 0 .455v9.943c0 .25.203.454.455.454h9.093v2.016H5.302a.454.454 0 1 0 0 .91H14.7a.455.455 0 1 0 0-.91h-4.243v-2.016h9.089a.454.454 0 0 0 .454-.454V.455A.454.454 0 0 0 19.546 0H.454Zm.454.909h18.182v9.034H.91V.91Z"
                                                    fill="#000"
                                                ></path>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> -->
                    </div>
                </div>
                <div class="col-lg-5" id="map">
                    <!-- <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d52926917.046263084!2d-171.98853098690284!3d35.93711882409233!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2feab43c6c725f5b%3A0xc918bf850e7ce0c9!2sSearchastay!5e0!3m2!1sen!2sin!4v1730204230026!5m2!1sen!2sin"
                        width="100%"
                        height="875px"
                        style="border: 0; border-radius: 8px;"
                        allowfullscreen=""
                        loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade"
                    ></iframe> -->
                </div>
            </div>
        </div>
    </section>
    <section class="pt-4">
        <img src="assest/images/listing/listing_banner2.jpg" class="w-100 banner_props object-fit-cover" alt="" />
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyABIHMb9YzuP3FRlceNccs3O4PjYdGb89M&callback=loadMap" 
        async defer></script>
<script type="text/javascript">
	function loadMap() {

	  const locations = <?php echo json_encode($locations, 15, 512) ?>;

	  let mapOptions = {
	    center: new google.maps.LatLng(locations[0]['lat'], locations[0]['lon']),
	    zoom: 10,
	    mapTypeId: google.maps.MapTypeId.ROADMAP
	  }
	  
	  // Moved this line up here
	  this.map = new google.maps.Map(document.getElementById('map'), mapOptions); // changed the "native element" to a standard DOM element for the sake of this example

	  var infowindow = new google.maps.InfoWindow();

	  var marker, i;

	  for (i = 0; i < locations.length; i++) {
	  	// console.log(locations[i]['lat']);
	    marker = new google.maps.Marker({
	      position: new google.maps.LatLng(locations[i]['lat'], locations[i]['lon']),
	      map: this.map // You are using this.map here so it needs to be created before
	    });

	    google.maps.event.addListener(marker, 'click', (function(marker, i) {
	      return function() {
	        infowindow.setContent(locations[i]['lat']);
	        infowindow.open(Map, marker);
	      }
	    })(marker, i));
	  }
	}

	$(document).on('change','#location_filter',function(){
		var location = $(this).val();

		var url = "<?php echo e(route('properties', ['location' => '__location__'])); ?>";
	    url = url.replace('__location__', location);
	    window.location = url;
	})
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\Nyc\resources\views/user/properties/properties.blade.php ENDPATH**/ ?>